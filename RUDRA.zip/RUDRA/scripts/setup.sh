#!/bin/bash
set -e
echo "Setting up R.U.D.R.A..."

python3 -m venv .venv 2>/dev/null || echo "venv exists"
source .venv/bin/activate 2>/dev/null || true

pip install -r requirements.txt

mkdir -p data/memory data/vectors data/uploads logs

if [ ! -f .env ]; then
  cp .env.example .env
  echo ".env created - add API keys"
fi

echo "Verifying core guard..."
python3 -c "from rudra.core.immutable import guard; print(guard.get_core_rules())"

echo "RUDRA ready. Run: python main.py"
