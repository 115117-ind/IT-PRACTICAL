#!/usr/bin/env python3
"""
R.U.D.R.A. Launcher - Real-time Universal Decision & Reasoning Agent
Master: Run with `python main.py` or `uvicorn rudra.api.server:app --reload`
"""
import uvicorn