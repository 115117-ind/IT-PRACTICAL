"""Phase 5 - Knowledge System"""
import json
from pathlib import Path
from typing import List, Dict, Any
from rudra.utils.logger import get_logger

logger = get_logger("knowledge")

class KnowledgeBase:
    def __init__(self, path: str = "data/knowledge"):
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)
        self.store = self.path / "kb.json"
        self.data: Dict[str, List[Dict]] = self._load()

    def _load(self) -> Dict:
        if self.store.exists():
            try:
                return json.loads(self.store.read_text())
            except: return {}
        return {"documents": [], "websites": [], "pdfs": [], "notes": [], "company": [], "personal": []}

    def _save(self):
        self.store.write_text(json.dumps(self.data, indent=2))

    def add(self, category: str, title: str, content: str, metadata: Dict=None):
        if category not in self.data:
            self.data[category] = []
        entry = {"title": title, "content": content[:5000], "meta": metadata or {}}
        self.data[category].append(entry)
        self._save()
        logger.info(f"Knowledge added: [{category}] {title}")
        return entry

    def add_document(self, title: str, content: str): return self.add("documents", title, content)
    def add_website(self, url: str, content: str): return self.add("websites", url, content, {"url": url})
    def add_pdf(self, filename: str, content: str): return self.add("pdfs", filename, content)
    def add_note(self, note: str): return self.add("notes", "note", note)
    def add_personal(self, info: str): return self.add("personal", "personal", info)

    def search_text(self, query: str, top_k=3) -> List[Dict]:
        # Simple keyword search (vector search in retrieval layer)
        results = []
        q = query.lower()
        for cat, items in self.data.items():
            for it in items:
                score = 0
                if q in it["title"].lower(): score += 2
                if q in it["content"].lower(): score += 1
                if score > 0:
                    results.append({**it, "category": cat, "score": score})
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    def get_all(self) -> Dict:
        return self.data

knowledge_base = KnowledgeBase()
