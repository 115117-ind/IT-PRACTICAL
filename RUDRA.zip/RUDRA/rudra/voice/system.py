"""Phase 16 - Voice System"""
from typing import Optional
from rudra.utils.logger import get_logger

logger = get_logger("voice")

class VoiceSystem:
    def __init__(self):
        self.wake_word = "Rudra"
        self.listening = False

    def detect_wake_word(self, text: str) -> bool:
        return self.wake_word.lower() in text.lower()

    async def speech_to_text(self, audio_bytes: bytes) -> str:
        try:
            import speech_recognition as sr
            import io, tempfile, os
            r = sr.Recognizer()
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                f.write(audio_bytes)
                fname = f.name
            with sr.AudioFile(fname) as source:
                audio = r.record(source)
            text = r.recognize_google(audio)
            os.unlink(fname)
            logger.info(f"STT: {text[:100]}")
            return text
        except Exception as e:
            logger.warning(f"STT failed {e}, returning stub")
            return "[voice input - STT requires microphone + API key]"

    async def text_to_speech(self, text: str, voice: str = "default") -> str:
        try:
            import pyttsx3
            engine = pyttsx3.init()
            # Save to file
            from pathlib import Path
            p = Path("data/voice")
            p.mkdir(parents=True, exist_ok=True)
            out = p / "output.mp3"
            engine.save_to_file(text, str(out))
            engine.runAndWait()
            logger.info(f"TTS saved to {out}")
            return str(out)
        except Exception as e:
            logger.warning(f"TTS fallback {e}")
            # Browser will use Web Speech API as fallback
            return f"data:tts-fallback:{text[:100]}"

    def voice_activity_detected(self, audio_level: float, threshold=0.3) -> bool:
        return audio_level > threshold

    def filter_noise(self, audio_bytes: bytes) -> bytes:
        # Placeholder - real noise filtering via RNNoise would go here
        return audio_bytes

voice_system = VoiceSystem()
