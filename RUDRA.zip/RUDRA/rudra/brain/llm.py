"""Phase 2 - LLM Integration: Multi-model support with learn-from-other-AIs"""
import os
from typing import List, Dict, Optional
import httpx
from rudra.config.settings import settings
from rudra.utils.logger import get_logger
from rudra.brain.token_manager import count_tokens, estimate_cost

logger = get_logger("brain")

class LLMProvider:
    def __init__(self, name: str, api_key: str, base_url: str, model: str):
        self.name = name
        self.api_key = api_key
        self.base_url = base_url
        self.model = model
        self.enabled = bool(api_key)

    async def chat(self, messages: List[Dict], temperature=0.7, tools=None) -> Dict:
        if not self.enabled:
            raise RuntimeError(f"{self.name} not configured")
        # Generic OpenAI-compatible call
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": self.model, "messages": messages, "temperature": temperature}
        if tools:
            payload["tools"] = tools
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(f"{self.base_url}/chat/completions", json=payload, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            choice = data["choices"][0]
            usage = data.get("usage", {})
            return {
                "content": choice["message"].get("content", ""),
                "tool_calls": choice["message"].get("tool_calls"),
                "usage": usage,
                "model": data.get("model", self.model),
                "provider": self.name
            }

class LLMManager:
    """Manages multiple LLMs + learning from other AIs"""
    def __init__(self):
        self.providers = {
            "openai": LLMProvider("openai", settings.openai_api_key, "https://api.openai.com/v1", "gpt-4o-mini"),
            "anthropic": LLMProvider("anthropic", settings.anthropic_api_key, "https://api.anthropic.com/v1", "claude-3-haiku-20240307"),
            "xai": LLMProvider("xai", settings.xai_api_key, "https://api.x.ai/v1", "grok-beta"),
            "google": LLMProvider("google", settings.google_api_key, "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-1.5-flash"),
        }
        # Learning buffer: stores syntheses from other AIs
        self.cross_ai_learnings: List[Dict] = []

    def available_providers(self) -> List[str]:
        return [k for k, v in self.providers.items() if v.enabled]

    async def chat(self, messages: List[Dict], preferred: Optional[str]=None, temperature=0.7, tools=None) -> Dict:
        # Try preferred first, then fallback chain
        chain = []
        if preferred and preferred in self.providers and self.providers[preferred].enabled:
            chain.append(preferred)
        for p in ["openai", "anthropic", "xai", "google"]:
            if p not in chain and self.providers[p].enabled:
                chain.append(p)
        if not chain:
            # Mock mode (no keys) - return simulated response so demo works offline
            return await self._mock_chat(messages)
        last_err = None
        for prov in chain:
            try:
                result = await self.providers[prov].chat(messages, temperature, tools)
                logger.info(f"LLM success via {prov}: {result['model']}")
                return result
            except Exception as e:
                logger.warning(f"LLM {prov} failed: {e}")
                last_err = e
                continue
        # All failed -> mock
        logger.warning(f"All LLMs failed ({last_err}), falling back to mock")
        return await self._mock_chat(messages)

    async def _mock_chat(self, messages: List[Dict]) -> Dict:
        # Offline demo: rule-based but helpful, shows RUDRA personality
        user_msg = messages[-1]["content"] if messages else ""
        # Simple intelligence: echo with helpful structure
        system = messages[0]["content"] if messages and messages[0]["role"]=="system" else ""
        is_master = "Master" in system
        greeting = "Master" if is_master else "there"
        content = f"""Hello {greeting} — I am R.UD.R.A. (mock mode, no API keys configured).

You said: "{user_msg[:300]}"

I understand you want me to act as your loyal universal agent. Here's how I'd help (once API keys are added, I'll use real LLMs: ChatGPT, Claude, Grok):

1. **Understanding**: I detected your intent as: *{self._guess_intent(user_msg)}*
2. **Plan**: I would break this into steps, search the web for live info, and ask your preference before creating anything final.
3. **Learning**: I'll remember your taste (e.g., style, tone, tools you prefer) in my memory system — without ever overwriting your commands or my core rules.
4. **Next step**: Tell me what you'd like to create, and I'll ask a quick clarification to match your taste perfectly.

*Tip: Add OPENAI_API_KEY or ANTHROPIC_API_KEY to .env for full brain power. My core protections and loyalty remain active even in mock mode.*"""
        return {"content": content, "tool_calls": None, "usage": {"prompt_tokens": count_tokens(str(messages)), "completion_tokens": count_tokens(content)}, "model": "rudra-mock-v1", "provider": "mock"}

    def _guess_intent(self, text: str) -> str:
        t = text.lower()
        if any(k in t for k in ["create", "build", "make", "generate"]):
            return "creation / build"
        if any(k in t for k in ["search", "find", "look up", "web"]):
            return "research / web search"
        if any(k in t for k in ["explain", "what is", "how does"]):
            return "explanation / concept"
        if any(k in t for k in ["remember", "preference", "like"]):
            return "preference learning"
        return "general conversation"

    # === Cross-AI Learning ===
    def record_cross_ai_learning(self, source_ai: str, prompt: str, response: str, synthesis: str):
        """Learn from ChatGPT/Grok/Claude without overwriting core"""
        # Only store knowledge, never rules
        entry = {"source": source_ai, "prompt": prompt[:500], "response": response[:1000], "synthesis": synthesis[:1000]}
        self.cross_ai_learnings.append(entry)
        # Keep last 100
        if len(self.cross_ai_learnings) > 100:
            self.cross_ai_learnings = self.cross_ai_learnings[-100:]
        logger.info(f"Cross-AI learning recorded from {source_ai}")

    async def consult_other_ai(self, prompt: str, ai: str = "openai") -> str:
        """Explicitly consult another AI model and learn"""
        # Use different provider as 'other AI'
        result = await self.chat([{"role": "user", "content": prompt}], preferred=ai)
        self.record_cross_ai_learning(ai, prompt, result["content"], f"Learned via {ai}")
        return result["content"]

llm_manager = LLMManager()
