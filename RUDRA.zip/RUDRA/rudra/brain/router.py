"""Phase 2 - Model Routing"""
from typing import Dict, List

class ModelRouter:
    """Capability-based routing"""
    CAPABILITIES = {
        "coding": ["openai", "anthropic"],
        "reasoning": ["openai", "anthropic", "xai"],
        "creative": ["openai", "google"],
        "fast": ["google", "openai"],
        "vision": ["openai", "google", "anthropic"],
        "research": ["xai", "openai"],
    }

    def __init__(self, llm_manager):
        self.llm = llm_manager

    def route(self, task_type: str, available: List[str]) -> str:
        prefs = self.CAPABILITIES.get(task_type, ["openai", "anthropic", "xai", "google"])
        for p in prefs:
            if p in available:
                return p
        return available[0] if available else "openai"

    def route_by_intent(self, intent: str) -> str:
        mapping = {
            "code": "coding", "build": "coding", "create": "coding",
            "search": "research", "research": "research",
            "image": "vision", "see": "vision",
            "chat": "fast"
        }
        for k, v in mapping.items():
            if k in intent.lower():
                return self.route(v, self.llm.available_providers() or ["openai"])
        return self.route("fast", self.llm.available_providers() or ["openai"])
