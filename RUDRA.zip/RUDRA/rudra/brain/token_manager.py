"""Phase 2 - Token Manager"""
try:
    import tiktoken
    _enc = tiktoken.get_encoding("cl100k_base")
    def count_tokens(text: str) -> int:
        return len(_enc.encode(text))
except:
    def count_tokens(text: str) -> int:
        return len(text) // 4

def estimate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    pricing = {
        "gpt-4o": (5.0/1_000_000, 15.0/1_000_000),
        "gpt-4o-mini": (0.15/1_000_000, 0.60/1_000_000),
        "claude-3-haiku": (0.25/1_000_000, 1.25/1_000_000),
        "grok-beta": (5.0/1_000_000, 15.0/1_000_000),
    }
    inp, out = pricing.get(model, (1.0/1_000_000, 1.0/1_000_000))
    return prompt_tokens*inp + completion_tokens*out
