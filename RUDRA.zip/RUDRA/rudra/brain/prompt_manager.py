"""Phase 2 - Prompt Manager"""
from pathlib import Path
import yaml

class PromptManager:
    def __init__(self):
        self.prompts = {
            "research": "You are a research assistant. Use web search and citations. Be thorough and cite sources.",
            "coding": "You are an expert coder. Write clean, tested, production-ready code. Ask for Master taste before finalizing UI.",
            "planning": "Decompose the goal into steps with dependencies. Output JSON with tasks array.",
            "review": "Review the output for correctness, safety, and alignment with Master preferences. Suggest fixes.",
            "vision": "Describe the image in detail, OCR any text, and identify objects.",
            "summarize": "Summarize the conversation, extracting preferences, decisions, and todos.",
        }

    def get(self, name: str, fallback="") -> str:
        return self.prompts.get(name, fallback)

    def render(self, name: str, **kwargs) -> str:
        template = self.get(name, "")
        for k, v in kwargs.items():
            template = template.replace(f"{{{k}}}", str(v))
        return template

    def register(self, name: str, prompt: str):
        self.prompts[name] = prompt
