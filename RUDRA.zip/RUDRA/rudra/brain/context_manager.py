"""Phase 2 - Context Manager"""
from typing import List, Dict

class ContextManager:
    def __init__(self, max_tokens=120000, buffer=2000):
        self.max_tokens = max_tokens
        self.buffer = buffer

    def build_context(self, system_prompt: str, history: List[Dict], memories: str = "", knowledge: str = "", user_input: str = "") -> List[Dict]:
        messages = [{"role": "system", "content": system_prompt}]
        # Inject memories/knowledge into system? Already in system prompt, keep separate for clarity
        # History already summarized; add recent turns
        for h in history[-10:]:
            messages.append(h)
        messages.append({"role": "user", "content": user_input})
        return messages

    def truncate_if_needed(self, messages: List[Dict], token_counter) -> List[Dict]:
        # Simple truncation: keep system + last N turns
        total = sum(token_counter(m["content"]) for m in messages)
        while total > (self.max_tokens - self.buffer) and len(messages) > 3:
            # Remove oldest history (index 1)
            removed = messages.pop(1)
            total -= token_counter(removed["content"])
        return messages
