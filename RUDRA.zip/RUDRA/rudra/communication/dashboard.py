"""Phase 20 - Communication Layer stub (dashboard is static HTML)"""
# FastAPI serves dashboard/index.html statically. This file holds helpers for chat/voice/mobile/desktop/web notifications.

from typing import Dict, List

class CommunicationLayer:
    def __init__(self):
        self.channels = ["chat", "voice", "websocket", "rest"]

    def notify_master(self, title: str, message: str, channel="dashboard"):
        print(f"[NOTIFY {channel}] {title}: {message}")
        return {"sent": True, "channel": channel}

    def broadcast(self, event: str, data: Dict):
        # In prod, push via WebSocket manager
        return {"event": event, "data": data}

comm = CommunicationLayer()
