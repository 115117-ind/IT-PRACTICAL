"""Phase 8 - Decision Engine"""
import re
from typing import Dict, List, Any, Tuple
from rudra.utils.logger import get_logger

logger = get_logger("decision")

class DecisionEngine:
    def __init__(self):
        self.intent_patterns = {
            "create": ["create", "build", "make", "generate", "design", "develop"],
            "search": ["search", "find", "look up", "research", "web", "news"],
            "file": ["file", "upload", "download", "document", "pdf", "read"],
            "code": ["code", "program", "script", "function", "debug"],
            "control": ["open", "click", "type", "screenshot", "control computer"],
            "voice": ["speak", "say", "voice", "pronounce"],
            "vision": ["image", "picture", "photo", "see", "look at", "analyze image"],
            "remember": ["remember", "save preference", "my taste", "I like"],
            "plan": ["plan", "schedule", "workflow", "steps"],
        }
        self.tool_map = {
            "create": ["ask_preference", "generate_content"],
            "search": ["web_search", "crawler"],
            "file": ["file_manager", "document_parser"],
            "code": ["code_executor"],
            "control": ["automation_engine"],
            "voice": ["text_to_speech"],
            "vision": ["image_understanding"],
            "remember": ["memory_update"],
            "plan": ["planner"],
        }

    def detect_intent(self, text: str) -> Tuple[str, float]:
        text_low = text.lower()
        scores = {}
        for intent, keywords in self.intent_patterns.items():
            score = sum(1 for kw in keywords if kw in text_low) / len(keywords)
            # Boost if exact phrase
            if any(kw in text_low for kw in keywords):
                score += 0.3
            scores[intent] = score
        best = max(scores, key=scores.get)
        conf = scores[best]
        # If very low, default to chat
        if conf < 0.2:
            return "chat", 0.5
        return best, min(conf, 1.0)

    def detect_goals(self, text: str) -> List[str]:
        # Simple goal extraction via sentences with verbs
        sentences = re.split(r'[.!?]', text)
        goals = [s.strip() for s in sentences if len(s.strip().split()) > 3]
        return goals[:3]

    def decompose_task(self, text: str, intent: str) -> List[Dict]:
        # Task decomposition
        if intent == "create":
            return [
                {"step": 1, "action": "clarify_preference", "desc": "Ask Master taste/opinion before creating"},
                {"step": 2, "action": "research", "desc": "Gather context/inspiration via web/KB"},
                {"step": 3, "action": "generate", "desc": "Create draft"},
                {"step": 4, "action": "review", "desc": "Review with Master"},
            ]
        if intent == "search":
            return [
                {"step": 1, "action": "web_search", "desc": "Search web for live info"},
                {"step": 2, "action": "rerank", "desc": "Rerank and synthesize"},
                {"step": 3, "action": "cite", "desc": "Provide citations"},
            ]
        if intent == "code":
            return [
                {"step": 1, "action": "plan", "desc": "Design architecture"},
                {"step": 2, "action": "code", "desc": "Write code"},
                {"step": 3, "action": "test", "desc": "Validate"},
            ]
        return [{"step": 1, "action": "respond", "desc": "Direct answer"}]

    def select_tools(self, intent: str, confidence: float) -> List[str]:
        tools = self.tool_map.get(intent, [])
        if confidence < 0.65:
            tools = ["clarification"] + tools
        return tools

    def confidence_scoring(self, intent_conf: float, has_context: bool, memory_hit: bool) -> float:
        score = intent_conf
        if has_context: score += 0.1
        if memory_hit: score += 0.1
        return min(score, 1.0)

    def needs_clarification(self, confidence: float, threshold=0.65) -> bool:
        return confidence < threshold

    def decide(self, text: str, has_context=False, memory_hit=False) -> Dict[str, Any]:
        intent, intent_conf = self.detect_intent(text)
        goals = self.detect_goals(text)
        tasks = self.decompose_task(text, intent)
        tools = self.select_tools(intent, intent_conf)
        confidence = self.confidence_scoring(intent_conf, has_context, memory_hit)
        clarification = self.needs_clarification(confidence)
        result = {
            "intent": intent,
            "intent_confidence": intent_conf,
            "goals": goals,
            "tasks": tasks,
            "tools": tools,
            "confidence": confidence,
            "needs_clarification": clarification,
            "clarification_question": self._clarification_q(intent, text) if clarification else None
        }
        logger.info(f"Decision: {result}")
        return result

    def _clarification_q(self, intent: str, text: str) -> str:
        qs = {
            "create": "Master, I want to match your taste perfectly — could you share the style, tone, or example you prefer for this creation?",
            "search": "Could you specify what aspect you'd like me to focus on, or how recent the info should be?",
            "code": "What tech stack or constraints should I respect, Master?",
            "chat": "Could you elaborate a bit so I can give you the most precise answer, Master?",
        }
        return qs.get(intent, "Could you provide a bit more detail, Master, so I deliver exactly what you want?")

decision_engine = DecisionEngine()
