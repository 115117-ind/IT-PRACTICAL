"""Phase 7 - Retrieval Engine (Embedding, Chunking, Hybrid, Reranking, Citation)"""
import re
from typing import List, Dict, Any
from pathlib import Path
from rudra.utils.logger import get_logger
from rudra.database.db import vector_db
from rudra.knowledge.base import knowledge_base

logger = get_logger("retrieval")

class RetrievalEngine:
    def __init__(self):
        self.chunk_size = 1000
        self.overlap = 200
        # Try to load sentence transformer, else fallback
        try:
            from sentence_transformers import SentenceTransformer
            self.model = SentenceTransformer("all-MiniLM-L6-v2")
            logger.info("Embedding model loaded: all-MiniLM-L6-v2")
        except Exception as e:
            self.model = None
            logger.warning(f"Embedding model not loaded ({e}), using fallback")

    def chunk(self, text: str) -> List[str]:
        chunks = []
        start = 0
        while start < len(text):
            end = start + self.chunk_size
            chunk = text[start:end]
            chunks.append(chunk)
            start = end - self.overlap
            if start < 0: start = 0
            if end >= len(text): break
        return chunks

    def embed(self, text: str) -> List[float]:
        if self.model:
            return self.model.encode(text).tolist()
        # Fallback hash embedding
        import hashlib
        h = hashlib.md5(text.encode()).hexdigest()
        vec = [int(h[i:i+2], 16)/255.0 for i in range(0, min(32, len(h)), 2)]
        return (vec * 24)[:384]

    def index(self, text: str, metadata: Dict):
        chunks = self.chunk(text)
        for ch in chunks:
            emb = self.embed(ch)
            vector_db.add(ch, metadata, emb)
        logger.info(f"Indexed {len(chunks)} chunks for {metadata}")

    def hybrid_search(self, query: str, top_k=5) -> List[Dict]:
        # Vector search
        q_emb = self.embed(query)
        vec_results = vector_db.search(q_emb, top_k=top_k)
        # Keyword search from KB
        kw_results = knowledge_base.search_text(query, top_k=top_k)
        # Merge
        combined = []
        for r in vec_results:
            combined.append({"text": r["text"], "meta": r["meta"], "score": 0.7, "source": "vector"})
        for r in kw_results:
            combined.append({"text": r["content"][:1000], "meta": {"title": r["title"], "category": r["category"]}, "score": r["score"]*0.5, "source": "keyword"})
        # Rerank by simple keyword overlap
        for r in combined:
            overlap = len(set(query.lower().split()) & set(r["text"].lower().split()))
            r["score"] += overlap * 0.1
        combined.sort(key=lambda x: x["score"], reverse=True)
        return combined[:top_k]

    def retrieve_with_citation(self, query: str, top_k=3) -> tuple[str, List[Dict]]:
        results = self.hybrid_search(query, top_k=top_k)
        if not results:
            return "", []
        context = ""
        citations = []
        for i, r in enumerate(results, 1):
            cite_id = f"[{i}]"
            context += f"{cite_id} {r['text'][:800]}\nSource: {r['meta']}\n\n"
            citations.append({"id": cite_id, "text": r["text"][:200], "meta": r["meta"], "score": r["score"]})
        return context, citations

retrieval = RetrievalEngine()
