"""Phase 4 - Memory System (All tiers) + Phase 18 Learning"""
import time
import json
from pathlib import Path
from typing import List, Dict, Any, Optional
from collections import defaultdict
from rudra.utils.logger import get_logger

logger = get_logger("memory")

class MemoryManager:
    def __init__(self, storage_path: str = "data/memory"):
        self.path = Path(storage_path)
        self.path.mkdir(parents=True, exist_ok=True)
        # In-memory stores (backed to JSON)
        self.short_term: Dict[str, List[Dict]] = defaultdict(list)  # session -> messages
        self.long_term: Dict[str, List[Dict]] = self._load("long_term.json")
        self.episodic: Dict[str, List[Dict]] = self._load("episodic.json")
        self.semantic: Dict[str, Any] = self._load("semantic.json", default={})
        self.user_profile: Dict[str, Dict] = self._load("user_profile.json")
        self.project_memory: Dict[str, List[Dict]] = self._load("project.json")
        self.preference_memory: Dict[str, Dict] = self._load("preferences.json")
        # Working memory (current session)
        self.working: Dict[str, Any] = {}

    def _load(self, fname, default=None):
        p = self.path / fname
        if p.exists():
            try:
                return json.loads(p.read_text())
            except: return default if default is not None else defaultdict(list)
        return default if default is not None else defaultdict(list)

    def _save(self, fname, data):
        p = self.path / fname
        p.write_text(json.dumps(data, indent=2))

    # === Short-term ===
    def add_short(self, user_id: str, role: str, content: str):
        self.short_term[user_id].append({"role": role, "content": content, "ts": time.time()})
        if len(self.short_term[user_id]) > 50:
            self.short_term[user_id] = self.short_term[user_id][-50:]

    def get_short(self, user_id: str, n=10) -> List[Dict]:
        return self.short_term[user_id][-n:]

    # === Long-term & Episodic ===
    def add_episodic(self, user_id: str, event: str, metadata: Dict=None):
        entry = {"event": event, "ts": time.time(), "meta": metadata or {}}
        if user_id not in self.episodic:
            self.episodic[user_id] = []
        self.episodic[user_id].append(entry)
        self._save("episodic.json", self.episodic)
        logger.info(f"Episodic saved for {user_id}: {event[:80]}")

    def add_long_term(self, user_id: str, fact: str, category="general"):
        if user_id not in self.long_term:
            self.long_term[user_id] = []
        self.long_term[user_id].append({"fact": fact, "category": category, "ts": time.time()})
        self._save("long_term.json", self.long_term)

    # === Semantic ===
    def set_semantic(self, key: str, value: Any):
        self.semantic[key] = value
        self._save("semantic.json", self.semantic)

    def get_semantic(self, key: str, default=None):
        return self.semantic.get(key, default)

    # === User Profile & Preferences (LEARNING) ===
    def update_profile(self, user_id: str, info: Dict):
        if user_id not in self.user_profile:
            self.user_profile[user_id] = {}
        self.user_profile[user_id].update(info)
        self._save("user_profile.json", self.user_profile)
        logger.info(f"Profile updated for {user_id}: {list(info.keys())}")

    def update_preference(self, user_id: str, key: str, value: Any, confidence=1.0):
        if user_id not in self.preference_memory:
            self.preference_memory[user_id] = {}
        # Preference learning: keep history, don't overwrite core rules
        prev = self.preference_memory[user_id].get(key)
        self.preference_memory[user_id][key] = {"value": value, "confidence": confidence, "ts": time.time(), "prev": prev}
        self._save("preferences.json", self.preference_memory)
        logger.info(f"Preference learned for {user_id}: {key}={value}")

    def get_preferences_text(self, user_id: str) -> str:
        prefs = self.preference_memory.get(user_id, {})
        if not prefs:
            return "No preferences yet - will learn from Master."
        lines = []
        for k, v in prefs.items():
            lines.append(f"- {k}: {v['value']} (confidence {v['confidence']})")
        return "\n".join(lines)

    def get_profile_text(self, user_id: str) -> str:
        prof = self.user_profile.get(user_id, {})
        if not prof:
            return "No profile yet."
        return json.dumps(prof, indent=2)

    # === Project Memory ===
    def add_project_memory(self, project_id: str, entry: str):
        if project_id not in self.project_memory:
            self.project_memory[project_id] = []
        self.project_memory[project_id].append({"entry": entry, "ts": time.time()})
        self._save("project.json", self.project_memory)

    # === Working Memory ===
    def set_working(self, key: str, value: Any):
        self.working[key] = value

    def get_working(self, key: str, default=None):
        return self.working.get(key, default)

    # === Retrieval for context ===
    def build_memory_context(self, user_id: str) -> str:
        parts = []
        # Preferences (most important for taste)
        prefs = self.get_preferences_text(user_id)
        parts.append(f"[PREFERENCES]\n{prefs}")
        # Recent episodic
        epis = self.episodic.get(user_id, [])[-3:]
        if epis:
            parts.append("[RECENT EPISODES]\n" + "\n".join(f"- {e['event'][:120]}" for e in epis))
        # Long term facts
        facts = self.long_term.get(user_id, [])[-5:]
        if facts:
            parts.append("[FACTS]\n" + "\n".join(f"- {f['fact'][:120]}" for f in facts))
        return "\n\n".join(parts)

    # === Summarization (Phase 18) ===
    def summarize_session(self, user_id: str, messages: List[Dict]) -> str:
        # Simple extractive summary
        summary = f"Session with {user_id}: {len(messages)} messages. Last: {messages[-1]['content'][:200] if messages else ''}"
        self.add_episodic(user_id, f"Session summary: {summary}")
        return summary

memory_manager = MemoryManager()
