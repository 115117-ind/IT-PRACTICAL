"""Phase 0 - Configuration System"""
import os
import yaml
from pathlib import Path
from pydantic_settings import BaseSettings
from pydantic import Field
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    env: str = Field(default="development", alias="RUDRA_ENV")
    master_user_id: str = Field(default="owner_001", alias="RUDRA_MASTER_USER_ID")
    master_name: str = Field(default="Master", alias="RUDRA_MASTER_NAME")
    secret_key: str = Field(default="dev-secret", alias="RUDRA_SECRET_KEY")
    core_hash_salt: str = Field(default="rudra-salt", alias="RUDRA_CORE_HASH_SALT")
    
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")
    anthropic_api_key: str = Field(default="", alias="ANTHROPIC_API_KEY")
    groq_api_key: str = Field(default="", alias="GROQ_API_KEY")
    google_api_key: str = Field(default="", alias="GOOGLE_API_KEY")
    xai_api_key: str = Field(default="", alias="XAI_API_KEY")
    
    database_url: str = Field(default="sqlite:///./data/rudra.db", alias="DATABASE_URL")
    vector_db_path: str = Field(default="./data/vectors", alias="VECTOR_DB_PATH")
    jwt_secret: str = Field(default="dev-jwt", alias="JWT_SECRET")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    class Config:
        env_file = ".env"
        extra = "allow"

settings = Settings()

def load_yaml_config(path: str = "config.yaml") -> dict:
    p = Path(path)
    if not p.exists():
        p = Path(__file__).parent.parent.parent / "config.yaml"
    if p.exists():
        with open(p, "r") as f:
            return yaml.safe_load(f)
    return {}

yaml_config = load_yaml_config()

def get_config(key_path: str, default=None):
    """Get nested config via dot path e.g. 'brain.routing_strategy'"""
    keys = key_path.split(".")
    cur = yaml_config
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return default
    return cur
