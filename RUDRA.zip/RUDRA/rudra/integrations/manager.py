"""Phase 12 - External Integrations (stubs with real interfaces)"""
from typing import Dict, Any, List
from rudra.utils.logger import get_logger
import httpx

logger = get_logger("integrations")

class IntegrationManager:
    def __init__(self):
        self.integrations = {
            "gmail": {"enabled": False, "desc": "Read/send emails (OAuth)"},
            "calendar": {"enabled": False, "desc": "Google Calendar events"},
            "github": {"enabled": False, "desc": "Repos, issues, PRs"},
            "slack": {"enabled": False, "desc": "Slack messages"},
            "discord": {"enabled": False, "desc": "Discord bot"},
            "whatsapp": {"enabled": False, "desc": "WhatsApp via Twilio"},
            "notion": {"enabled": False, "desc": "Notion pages/databases"},
            "gdrive": {"enabled": False, "desc": "Google Drive files"},
            "dropbox": {"enabled": False, "desc": "Dropbox storage"},
            "browser": {"enabled": True, "desc": "Browser automation (playwright)"},
            "os": {"enabled": True, "desc": "OS-level operations"},
        }

    def status(self) -> Dict:
        return self.integrations

    async def github_list_repos(self, token: str) -> List[Dict]:
        if not token:
            return [{"note": "Add GITHUB_TOKEN to .env to enable"}]
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get("https://api.github.com/user/repos?per_page=5", headers={"Authorization": f"Bearer {token}"})
            if resp.status_code == 200:
                return [{"name": r["name"], "url": r["html_url"]} for r in resp.json()[:5]]
            return [{"error": resp.text[:500]}]

    async def gmail_list(self, creds: Dict=None) -> List[Dict]:
        return [{"note": "Gmail requires OAuth - configure GMAIL_CLIENT_ID/SECRET, then visit /api/auth/gmail"}]

    async def notion_query(self, token: str, database_id: str) -> Dict:
        return {"note": "Add NOTION_TOKEN and database_id"}

integrations = IntegrationManager()
