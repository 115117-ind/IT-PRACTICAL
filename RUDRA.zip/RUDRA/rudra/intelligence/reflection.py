"""Phase 24 - Advanced Intelligence (Reflection, Self-correction, Goal tracking)"""
import time
from typing import List, Dict, Any
from rudra.utils.logger import get_logger
from rudra.memory.manager import memory_manager

logger = get_logger("intelligence")

class AdvancedIntelligence:
    def __init__(self):
        self.goals: Dict[str, Dict] = {}
        self.reflections: List[Dict] = []

    def track_goal(self, goal_id: str, description: str, target_time: float = None):
        self.goals[goal_id] = {"description": description, "created": time.time(), "target": target_time, "progress": 0, "status": "active"}
        logger.info(f"Goal tracked: {goal_id} - {description}")

    def update_goal_progress(self, goal_id: str, progress: float, note: str=""):
        if goal_id in self.goals:
            self.goals[goal_id]["progress"] = progress
            if progress >= 100:
                self.goals[goal_id]["status"] = "completed"
            logger.info(f"Goal {goal_id} progress {progress}% {note}")

    async def reflect(self, session_messages: List[Dict], outcome: str, success: bool) -> str:
        """Self-evaluation"""
        # Simple reflection: what went well, what to improve
        reflection = {
            "ts": time.time(),
            "success": success,
            "outcome": outcome[:500],
            "lesson": "Remember Master taste and ask opinion next time" if not success else "Continue pattern that succeeded",
            "improvement": "Add more citations" if not success else "None"
        }
        self.reflections.append(reflection)
        logger.info(f"Reflection: {reflection}")
        # Store as episodic memory but never overwrite core rules
        memory_manager.add_episodic("system", f"Reflection: {reflection['lesson']}")
        return reflection["lesson"]

    async def self_correct(self, last_output: str, feedback: str) -> str:
        corrected = f"Corrected based on feedback '{feedback}': {last_output[:500]} -> Improved version addressing: {feedback}"
        logger.info(f"Self-correction applied")
        return corrected

    async def retry_with_backoff(self, func, max_retries=3, backoff=1.0):
        import asyncio
        for attempt in range(max_retries):
            try:
                return await func()
            except Exception as e:
                if attempt == max_retries-1:
                    raise
                wait = backoff * (2 ** attempt)
                logger.warning(f"Retry {attempt+1}/{max_retries} after {wait}s: {e}")
                await asyncio.sleep(wait)

    def optimize_workflow(self, plan: Any) -> Any:
        # Stub: reorder tasks by dependencies and priority
        if hasattr(plan, "tasks"):
            plan.tasks.sort(key=lambda t: (len(t.dependencies), -t.priority))
        return plan

    def autonomous_schedule(self, task: str, cron: str, user_id: str) -> Dict:
        # Only if Master allows
        from rudra.config.settings import settings
        if user_id != settings.master_user_id:
            return {"error": "Autonomous scheduling requires Master permission"}
        # In prod, register with APScheduler
        logger.info(f"Scheduled autonomous task: {task} cron={cron}")
        return {"scheduled": True, "task": task, "cron": cron}

reflection_engine = AdvancedIntelligence()
