"""Phase 9 - Planning Engine"""
import time
from typing import List, Dict, Any
from dataclasses import dataclass, field
from rudra.utils.logger import get_logger

logger = get_logger("planning")

@dataclass
class Task:
    id: str
    title: str
    description: str
    dependencies: List[str] = field(default_factory=list)
    status: str = "pending" # pending, running, done, failed
    assigned_agent: str = "execution"
    priority: int = 1

@dataclass
class Plan:
    goal: str
    tasks: List[Task]
    created_at: float = field(default_factory=time.time)
    status: str = "active"

class PlanningEngine:
    def __init__(self):
        self.active_plans: Dict[str, Plan] = {}

    def create_plan(self, goal: str, decomposed: List[Dict]) -> Plan:
        tasks = []
        for i, d in enumerate(decomposed):
            tid = f"task_{i+1}"
            deps = [f"task_{i}"] if i>0 else []
            tasks.append(Task(id=tid, title=d.get("action","step"), description=d.get("desc",""), dependencies=deps))
        plan = Plan(goal=goal, tasks=tasks)
        self.active_plans[goal] = plan
        logger.info(f"Plan created for goal: {goal} with {len(tasks)} tasks")
        return plan

    def next_tasks(self, plan: Plan) -> List[Task]:
        done = {t.id for t in plan.tasks if t.status=="done"}
        ready = []
        for t in plan.tasks:
            if t.status != "pending": continue
            if all(dep in done for dep in t.dependencies):
                ready.append(t)
        return ready

    def update_task(self, plan: Plan, task_id: str, status: str):
        for t in plan.tasks:
            if t.id == task_id:
                t.status = status
                logger.info(f"Task {task_id} -> {status}")
                break

    def is_complete(self, plan: Plan) -> bool:
        return all(t.status=="done" for t in plan.tasks)

    async def execute_plan(self, plan: Plan, executor_func):
        """Multi-step execution with retry"""
        while not self.is_complete(plan):
            ready = self.next_tasks(plan)
            if not ready:
                # deadlock or failed deps
                break
            for task in ready:
                self.update_task(plan, task.id, "running")
                try:
                    await executor_func(task)
                    self.update_task(plan, task.id, "done")
                except Exception as e:
                    logger.error(f"Task {task.id} failed: {e}")
                    self.update_task(plan, task.id, "failed")
                    # retry once
                    try:
                        await executor_func(task)
                        self.update_task(plan, task.id, "done")
                    except: pass
                # background planning yield
                await self._yield()
        return plan

    async def _yield(self):
        import asyncio
        await asyncio.sleep(0.01)

planner = PlanningEngine()
