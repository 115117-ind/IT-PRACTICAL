"""Phase 22 - Monitoring"""
import time
from typing import Dict, Any, List
from collections import defaultdict, deque
from rudra.utils.logger import get_logger

logger = get_logger("monitoring")

class Metrics:
    def __init__(self):
        self.counters: Dict[str, int] = defaultdict(int)
        self.latencies: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        self.costs: List[Dict] = []
        self.errors: List[Dict] = []
        self.start_times: Dict[str, float] = {}

    def inc(self, name: str, value=1):
        self.counters[name] += value

    def start_timer(self, name: str):
        self.start_times[name] = time.time()

    def end_timer(self, name: str) -> float:
        start = self.start_times.pop(name, time.time())
        latency = (time.time() - start) * 1000
        self.latencies[name].append(latency)
        logger.info(f"Metric {name}: {latency:.1f}ms")
        return latency

    def record_cost(self, model: str, prompt_tokens: int, completion_tokens: int, cost: float):
        self.costs.append({"model": model, "prompt": prompt_tokens, "completion": completion_tokens, "cost": cost, "ts": time.time()})
        self.inc("total_cost_cents", int(cost*100))

    def record_error(self, where: str, error: str):
        self.errors.append({"where": where, "error": error, "ts": time.time()})
        self.inc("errors")

    def summary(self) -> Dict[str, Any]:
        avg_lat = {k: sum(v)/len(v) if v else 0 for k, v in self.latencies.items()}
        total_cost = sum(c["cost"] for c in self.costs)
        return {
            "counters": dict(self.counters),
            "avg_latency_ms": avg_lat,
            "total_cost_usd": round(total_cost, 4),
            "error_count": len(self.errors),
            "recent_errors": self.errors[-5:]
        }

metrics = Metrics()
