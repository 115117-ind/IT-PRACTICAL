"""Phase 19 - Multi-Agent System"""
import asyncio
from typing import Dict, List, Any
from rudra.utils.logger import get_logger
from rudra.brain.llm import llm_manager
from rudra.brain.prompt_manager import PromptManager

logger = get_logger("multi_agent")

class Agent:
    def __init__(self, name: str, role: str, system_prompt: str):
        self.name = name
        self.role = role
        self.system_prompt = system_prompt

    async def run(self, task: str, context: str = "") -> str:
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": f"Task: {task}\nContext: {context}"}
        ]
        result = await llm_manager.chat(messages)
        return result["content"]

class MultiAgentSystem:
    def __init__(self):
        pm = PromptManager()
        self.agents = {
            "planner": Agent("Planner", "planner", pm.get("planning") + " You are the Planner. Loyalty to Master."),
            "researcher": Agent("Researcher", "researcher", pm.get("research") + " Always cite sources."),
            "coder": Agent("Coder", "coder", pm.get("coding")),
            "vision": Agent("Vision", "vision", pm.get("vision")),
            "voice": Agent("Voice", "voice", "You handle voice I/O, STT/TTS."),
            "memory": Agent("Memory", "memory", "You manage memory tiers and preferences."),
            "reviewer": Agent("Reviewer", "reviewer", pm.get("review")),
            "executor": Agent("Executor", "executor", "You execute tasks step-by-step, safe and audited."),
        }

    async def run_workflow(self, goal: str, tasks: List[Dict]) -> Dict[str, Any]:
        results = {}
        for t in tasks:
            agent_name = self._assign_agent(t)
            agent = self.agents.get(agent_name, self.agents["executor"])
            logger.info(f"Agent {agent.name} running task {t.get('action')}")
            output = await agent.run(t.get("desc","") + f" | Goal: {goal}")
            results[t.get("action","task")] = {"agent": agent.name, "output": output}
            await asyncio.sleep(0.05)
        # Review phase
        review = await self.agents["reviewer"].run(f"Review outputs for goal: {goal}", str(results)[:3000])
        results["review"] = {"agent": "Reviewer", "output": review}
        return results

    def _assign_agent(self, task: Dict) -> str:
        a = task.get("action","").lower()
        if "research" in a or "search" in a: return "researcher"
        if "code" in a or "generate" in a: return "coder"
        if "plan" in a: return "planner"
        if "vision" in a or "image" in a: return "vision"
        if "memory" in a: return "memory"
        return "executor"

multi_agents = MultiAgentSystem()
