"""Phase 14 - Web Intelligence UPGRADED (v2)
Real-time search + crawl + scrape + news with multi-provider + caching + citations
Providers: Tavily (preferred if key) → SerpAPI → DuckDuckGo HTML → Wikipedia fallback
Features: snippet + full page extract, deduplication, cache (5min), real citations
"""
import os
import re
import time
import hashlib
import httpx
from bs4 import BeautifulSoup
from typing import List, Dict, Any, Optional
from urllib.parse import unquote, urlparse
from rudra.utils.logger import get_logger
from rudra.database.db import db

logger = get_logger("web")

class WebIntelligence:
    def __init__(self):
        self.headers = {
            "User-Agent": "RUDRA/1.0 (Master-loyal agent; +https://rudra.local)",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }
        self.cache_ttl = 300  # 5 min
        self.timeout = 15

    # ---------- helpers ----------
    def _cache_key(self, kind: str, query: str) -> str:
        return f"web:{kind}:{hashlib.md5(query.encode()).hexdigest()[:10]}"

    def _clean_url(self, href: str) -> str:
        # DuckDuckGo wraps: //duckduckgo.com/l/?uddg=https%3A...
        if not href:
            return href
        if "uddg=" in href:
            try:
                part = href.split("uddg=")[1].split("&")[0]
                return unquote(part)
            except: pass
        if href.startswith("//"):
            return "https:" + href
        return href

    def _extract_snippet(self, result_el) -> str:
        # DuckDuckGo snippet
        snip = result_el.select_one(".result__snippet")
        if snip:
            return snip.get_text(" ", strip=True)[:600]
        body = result_el.get_text(" ", strip=True)
        return body[:600]

    # ---------- SEARCH ----------
    async def search(self, query: str, max_results=5, mode: str = "general") -> List[Dict]:
        """
        Real-time web search. Returns List[{title, url, content, snippet, score}]
        - mode: general | news | images
        """
        cache_key = self._cache_key(f"search:{mode}", query)
        cached = db.cache_get(cache_key)
        if cached:
            logger.info(f"Web cache HIT for '{query}'")
            return cached

        results: List[Dict] = []
        # 1) Try Tavily
        tavily_key = os.getenv("TAVILY_API_KEY")
        if tavily_key:
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    payload = {
                        "api_key": tavily_key,
                        "query": query,
                        "max_results": max_results,
                        "search_depth": "advanced" if mode=="news" else "basic",
                        "include_answer": True,
                        "topic": "news" if mode=="news" else "general",
                    }
                    resp = await client.post("https://api.tavily.com/search", json=payload)
                    resp.raise_for_status()
                    data = resp.json()
                    for r in data.get("results", [])[:max_results]:
                        results.append({
                            "title": r.get("title",""),
                            "url": r.get("url",""),
                            "content": r.get("content","")[:800],
                            "snippet": r.get("content","")[:400],
                            "score": r.get("score",0),
                            "source": "tavily"
                        })
                    if results:
                        db.cache_set(cache_key, results, ttl=self.cache_ttl)
                        logger.info(f"Tavily search OK: {len(results)} for '{query}'")
                        return results
            except Exception as e:
                logger.warning(f"Tavily failed: {e}")

        # 2) Try SerpAPI
        serp_key = os.getenv("SERPAPI_KEY")
        if serp_key and not results:
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    resp = await client.get("https://serpapi.com/search", params={
                        "engine": "google" if mode!="news" else "google_news",
                        "q": query,
                        "api_key": serp_key,
                        "num": max_results
                    })
                    data = resp.json()
                    organic = data.get("organic_results") or data.get("news_results") or []
                    for r in organic[:max_results]:
                        results.append({
                            "title": r.get("title",""),
                            "url": r.get("link",""),
                            "content": r.get("snippet","")[:800],
                            "snippet": r.get("snippet","")[:400],
                            "score": 0.7,
                            "source": "serpapi"
                        })
                    if results:
                        db.cache_set(cache_key, results, ttl=self.cache_ttl)
                        return results
            except Exception as e:
                logger.warning(f"SerpAPI failed: {e}")

        # 3) DuckDuckGo HTML (no key, always works)
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                resp = await client.get(f"https://html.duckduckgo.com/html/?q={query}", headers=self.headers)
                resp.raise_for_status()
                soup = BeautifulSoup(resp.text, "lxml")
                blocks = soup.select(".result")[:max_results*2]  # grab extra then dedupe
                seen = set()
                for block in blocks:
                    a = block.select_one(".result__a")
                    if not a: continue
                    title = a.get_text(strip=True)
                    raw_url = a.get("href","")
                    url = self._clean_url(raw_url)
                    if not url or url in seen or "duckduckgo.com" in url:
                        continue
                    seen.add(url)
                    snippet = self._extract_snippet(block)
                    # Fetch first 500 chars of page for richer content when needed? lazy: use snippet
                    results.append({
                        "title": title,
                        "url": url,
                        "content": snippet,
                        "snippet": snippet[:300],
                        "score": 0.6,
                        "source": "duckduckgo"
                    })
                    if len(results) >= max_results:
                        break
                if results:
                    db.cache_set(cache_key, results, ttl=self.cache_ttl)
                    logger.info(f"DuckDuckGo search OK: {len(results)} for '{query}'")
                    return results
        except Exception as e:
            logger.warning(f"DuckDuckGo search failed: {e}")

        # 4) Fallback: return search URL
        if not results:
            results = [{"title": f"Search: {query}", "url": f"https://duckduckgo.com/?q={query}", "content": "No live results — check URL directly. Add TAVILY_API_KEY for better search.", "snippet": "Fallback", "score": 0.1, "source": "fallback"}]
        db.cache_set(cache_key, results, ttl=self.cache_ttl)
        return results

    # ---------- CRAWL & SCRAPE ----------
    async def crawl(self, url: str, extract_mode: str = "readable") -> Dict:
        """
        Fetch URL and extract readable text (removes nav/footer/scripts)
        """
        cache_key = self._cache_key("crawl", url)
        cached = db.cache_get(cache_key)
        if cached:
            return cached
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True, headers=self.headers) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                html = resp.text
                soup = BeautifulSoup(html, "lxml")
                # Remove noise
                for tag in soup(["script","style","nav","footer","header","noscript","iframe"]):
                    tag.decompose()
                title = soup.title.string.strip() if soup.title and soup.title.string else urlparse(url).netloc
                # Prefer article/main
                article = soup.select_one("article") or soup.select_one("main") or soup.select_one("[role=main]") or soup.body
                if article:
                    text = article.get_text(separator="\n", strip=True)
                else:
                    text = soup.get_text(separator="\n", strip=True)
                # Clean text: collapse blank lines, trim
                text = re.sub(r"\n{3,}", "\n\n", text)[:12000]
                # Links (first 10 absolute)
                links = []
                for a in soup.find_all("a", href=True)[:12]:
                    href = a.get("href")
                    if href and href.startswith("http"):
                        links.append(href)
                result = {"url": url, "title": title, "text": text, "links": links, "status": resp.status_code}
                db.cache_set(cache_key, result, ttl=600)
                return result
        except Exception as e:
            logger.warning(f"Crawl failed {url}: {e}")
            return {"error": str(e), "url": url, "title": "", "text": ""}

    async def scrape(self, url: str, selector: str = "body") -> str:
        data = await self.crawl(url)
        if "error" in data:
            return f"Error crawling {url}: {data['error']}"
        return data["text"][:8000]

    async def read_url(self, url: str, max_chars=8000) -> str:
        d = await self.crawl(url)
        return d.get("text","")[:max_chars]

    # ---------- SPECIALIZED ----------
    async def news(self, topic: str, max_results=5) -> List[Dict]:
        # News = search with news mode + recency sort via query
        q = f"{topic} news today" if "news" not in topic.lower() else topic
        results = await self.search(q, max_results=max_results, mode="news")
        # Try to enrich with crawl for top result's date if needed
        return results

    async def search_and_crawl(self, query: str, max_results=3, crawl_top_k=2) -> List[Dict]:
        """
        Search then crawl top K pages for full content — best for synthesis with citations
        """
        hits = await self.search(query, max_results=max_results)
        enriched = []
        for h in hits[:crawl_top_k]:
            try:
                page = await self.crawl(h["url"])
                h["full_text"] = page.get("text","")[:2000]
                h["page_title"] = page.get("title","")
            except: h["full_text"] = h.get("content","")
            enriched.append(h)
        # Append remaining without crawl
        enriched += hits[crawl_top_k:]
        return enriched

    # ---------- LIVE INFO ----------
    async def live_info(self, query: str) -> Dict:
        """One-shot: search + synthesize snippet with citations"""
        results = await self.search_and_crawl(query, max_results=5, crawl_top_k=2)
        citations = [{"id": f"[{i+1}]", "title": r["title"], "url": r["url"], "snippet": r.get("snippet","")[:200]} for i,r in enumerate(results)]
        context = "\n\n".join(f"[{i+1}] {r['title']} ({r['url']})\n{r.get('full_text', r.get('content',''))[:800]}" for i,r in enumerate(results))
        return {"query": query, "context": context, "citations": citations, "results": results}

web = WebIntelligence()
