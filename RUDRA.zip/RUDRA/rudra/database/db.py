"""Phase 6 - Database Layer (SQLite + Vector stub + Cache)"""
import sqlite3
import json
import time
from pathlib import Path
from typing import List, Dict, Any
from rudra.utils.logger import get_logger

logger = get_logger("database")

DB_PATH = Path("data/rudra.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

class Database:
    def __init__(self, path: str = "data/rudra.db"):
        self.path = path
        self._init()

    def _init(self):
        conn = sqlite3.connect(self.path)
        c = conn.cursor()
        # Users
        c.execute("""CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT, profile TEXT, created_at REAL)""")
        # Conversations
        c.execute("""CREATE TABLE IF NOT EXISTS conversations (id TEXT PRIMARY KEY, user_id TEXT, session_id TEXT, role TEXT, content TEXT, timestamp REAL, metadata TEXT)""")
        # Memories
        c.execute("""CREATE TABLE IF NOT EXISTS memories (id TEXT PRIMARY KEY, user_id TEXT, type TEXT, content TEXT, timestamp REAL)""")
        # Knowledge
        c.execute("""CREATE TABLE IF NOT EXISTS knowledge (id TEXT PRIMARY KEY, category TEXT, title TEXT, content TEXT, metadata TEXT)""")
        # Analytics
        c.execute("""CREATE TABLE IF NOT EXISTS analytics (id INTEGER PRIMARY KEY AUTOINCREMENT, event TEXT, user_id TEXT, data TEXT, timestamp REAL)""")
        # Cache (key-value with TTL)
        c.execute("""CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT, expires_at REAL)""")
        conn.commit()
        conn.close()
        logger.info("Database initialized")

    def execute(self, sql: str, params=()):
        conn = sqlite3.connect(self.path)
        c = conn.cursor()
        c.execute(sql, params)
        conn.commit()
        conn.close()

    def query(self, sql: str, params=()) -> List:
        conn = sqlite3.connect(self.path)
        c = conn.cursor()
        c.execute(sql, params)
        rows = c.fetchall()
        conn.close()
        return rows

    # Cache helpers
    def cache_set(self, key: str, value: Any, ttl=3600):
        expires = time.time() + ttl
        self.execute("INSERT OR REPLACE INTO cache (key, value, expires_at) VALUES (?,?,?)", (key, json.dumps(value), expires))

    def cache_get(self, key: str):
        rows = self.query("SELECT value, expires_at FROM cache WHERE key=?", (key,))
        if not rows: return None
        val, exp = rows[0]
        if time.time() > exp:
            self.execute("DELETE FROM cache WHERE key=?", (key,))
            return None
        return json.loads(val)

    def log_analytics(self, event: str, user_id: str, data: Dict):
        self.execute("INSERT INTO analytics (event, user_id, data, timestamp) VALUES (?,?,?,?)", (event, user_id, json.dumps(data), time.time()))

db = Database()

class VectorDB:
    """Phase 7 stub: In-memory vector store (Chroma-ready)"""
    def __init__(self, path: str = "data/vectors"):
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)
        self.vectors: List[Dict] = []
        self._load()

    def _load(self):
        p = self.path / "vectors.json"
        if p.exists():
            try:
                import json as j
                self.vectors = j.loads(p.read_text())
            except: self.vectors = []

    def _save(self):
        import json as j
        (self.path / "vectors.json").write_text(j.dumps(self.vectors[-1000:], indent=2))

    def add(self, text: str, metadata: Dict, embedding: List[float]=None):
        # If no embedding model, use simple hash embedding
        if embedding is None:
            import hashlib
            h = hashlib.md5(text.encode()).hexdigest()
            embedding = [int(h[i:i+2], 16)/255.0 for i in range(0, min(32, len(h)), 2)]
            # Pad to 384
            embedding = (embedding * 24)[:384]
        self.vectors.append({"text": text[:2000], "meta": metadata, "embedding": embedding})
        self._save()

    def search(self, query_embedding: List[float], top_k=5) -> List[Dict]:
        # Cosine similarity mock if no model
        if not self.vectors:
            return []
        # Simple: return last items if no real embedding
        return self.vectors[-top_k:][::-1]

vector_db = VectorDB()
