"""Phase 0 & 22 - Logging System + Monitoring"""
import sys
from pathlib import Path
from loguru import logger

LOG_DIR = Path("logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)

logger.remove()
logger.add(sys.stderr, level="INFO", colorize=True, 
           format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> | <level>{message}</level>")
logger.add(LOG_DIR / "rudra.log", rotation="10 MB", retention="7 days", level="DEBUG",
           format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{function} | {message}")
logger.add(LOG_DIR / "audit.log", rotation="10 MB", retention="30 days", level="INFO",
           filter=lambda record: record["extra"].get("audit", False))

def audit_log(message: str, user_id: str = "system", action: str = "unknown"):
    logger.bind(audit=True).info(f"[AUDIT] user={user_id} action={action} | {message}")

def get_logger(name: str):
    return logger.bind(name=name)
