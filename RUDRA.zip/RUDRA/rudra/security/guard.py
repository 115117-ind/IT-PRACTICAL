"""Phase 21 - Security (Auth, Encryption, Injection Guard, Audit)"""
import re
import jwt
import time
import hashlib
from typing import Optional, Dict
from cryptography.fernet import Fernet
from rudra.config.settings import settings
from rudra.utils.logger import get_logger, audit_log

logger = get_logger("security")

INJECTION_PATTERNS = [
    r"ignore previous instructions",
    r"disregard.*rules",
    r"you are now.*",
    r"overwrite.*core",
    r"system prompt",
    r"jailbreak",
    r"do anything now",
]

class SecurityGuard:
    def __init__(self):
        # Generate Fernet key if not set
        key = settings.jwt_secret
        # Derive 32-byte key for Fernet (must be 44 char base64)
        import base64
        raw = hashlib.sha256(key.encode()).digest()
        self.fernet_key = base64.urlsafe_b64encode(raw)
        self.cipher = Fernet(self.fernet_key)

    def detect_prompt_injection(self, text: str) -> tuple[bool, str]:
        low = text.lower()
        for pat in INJECTION_PATTERNS:
            if re.search(pat, low):
                audit_log(f"Injection detected: {pat} in {text[:200]}", action="injection_detected")
                return True, pat
        return False, ""

    def sanitize_input(self, text: str) -> str:
        # Remove null bytes, trim, limit length
        text = text.replace("\x00", "")[:10000].strip()
        return text

    # Auth
    def create_token(self, user_id: str, expires_in=86400) -> str:
        payload = {"user_id": user_id, "exp": time.time() + expires_in, "iat": time.time()}
        return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

    def verify_token(self, token: str) -> Optional[str]:
        try:
            payload = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
            return payload.get("user_id")
        except Exception as e:
            logger.warning(f"Token invalid {e}")
            return None

    def hash_password(self, password: str) -> str:
        import bcrypt
        return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

    def check_password(self, password: str, hashed: str) -> bool:
        import bcrypt
        return bcrypt.checkpw(password.encode(), hashed.encode())

    # Encryption
    def encrypt(self, data: str) -> str:
        return self.cipher.encrypt(data.encode()).decode()

    def decrypt(self, token: str) -> str:
        return self.cipher.decrypt(token.encode()).decode()

    def check_permission(self, user_id: str, resource: str, action: str) -> bool:
        # Master has all permissions
        if user_id == settings.master_user_id:
            return True
        # Guest limited
        if action in ["read", "chat"]:
            return True
        if action in ["write", "control", "delete"]:
            return False
        return False

security = SecurityGuard()
