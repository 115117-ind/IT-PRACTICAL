"""Phase 11 - API Layer (REST + WebSocket + Auth)"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, UploadFile, File, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import time
from pathlib import Path

from rudra.core.runtime import rudra
from rudra.core.immutable import guard
from rudra.security.guard import security
from rudra.memory.manager import memory_manager
from rudra.knowledge.base import knowledge_base
from rudra.filesystem.manager import file_manager
from rudra.web.intelligence import web
from rudra.integrations.manager import integrations
from rudra.monitoring.metrics import metrics
from rudra.config.settings import settings
from rudra.vision.system import vision
from rudra.voice.system import voice_system
from rudra.utils.logger import get_logger, audit_log

logger = get_logger("api")

app = FastAPI(title="R.U.D.R.A. API", description="Real-time Universal Decision & Reasoning Agent", version="1.0.0")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# Serve dashboard
dashboard_path = Path(__file__).parent.parent.parent / "dashboard"
if dashboard_path.exists():
    app.mount("/dashboard", StaticFiles(directory=str(dashboard_path), html=True), name="dashboard")

# === Auth dependency ===
def get_user(authorization: Optional[str] = Header(None), x_user_id: Optional[str] = Header(None)) -> str:
    if authorization and authorization.startswith("Bearer "):
        token = authorization.split(" ",1)[1]
        uid = security.verify_token(token)
        if uid: return uid
    if x_user_id:
        return x_user_id
    return settings.master_user_id  # default to master for local use

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    user_id: Optional[str] = None

class PreferenceRequest(BaseModel):
    key: str
    value: str

# === Routes ===
@app.on_event("startup")
async def startup():
    await rudra.start()
    logger.info("API startup complete")

@app.get("/")
async def root():
    return {"name": "R.U.D.R.A.", "full": "Real-time Universal Decision & Reasoning Agent", "status": "loyal and ready", "master": settings.master_user_id, "docs": "/docs", "dashboard": "/dashboard/"}

@app.get("/health")
async def health():
    return rudra.get_status()

@app.post("/api/chat")
async def chat(req: ChatRequest, user_id: str = Depends(get_user)):
    uid = req.user_id or user_id
    result = await rudra.chat(uid, req.message, req.session_id)
    return result

@app.post("/api/create")
async def create(req: ChatRequest, user_id: str = Depends(get_user)):
    uid = req.user_id or user_id
    result = await rudra.create_thing(uid, req.message)
    return result

@app.get("/api/memory/preferences")
async def get_prefs(user_id: str = Depends(get_user)):
    return {"user_id": user_id, "preferences": memory_manager.preference_memory.get(user_id, {}), "profile": memory_manager.user_profile.get(user_id, {})}

@app.post("/api/memory/preferences")
async def set_pref(req: PreferenceRequest, user_id: str = Depends(get_user)):
    memory_manager.update_preference(user_id, req.key, req.value)
    return {"saved": True, "key": req.key}

@app.post("/api/memory/feedback")
async def feedback(data: Dict[str, Any], user_id: str = Depends(get_user)):
    from rudra.learning.system import learning
    learning.collect_feedback(user_id, data.get("message_id",""), data.get("rating",5), data.get("comment",""))
    return {"received": True}

@app.get("/api/knowledge")
async def list_knowledge():
    return knowledge_base.get_all()

@app.post("/api/knowledge/add")
async def add_knowledge(data: Dict[str, Any]):
    kb = knowledge_base.add(data.get("category","notes"), data.get("title",""), data.get("content",""), data.get("meta",{}))
    from rudra.retrieval.engine import retrieval
    retrieval.index(data.get("content",""), {"title": data.get("title","")})
    return kb

@app.get("/api/tools")
async def list_tools():
    from rudra.tools.registry import registry
    return {"tools": registry.list_tools()}

@app.post("/api/tools/execute")
async def exec_tool(data: Dict[str, Any], user_id: str = Depends(get_user)):
    from rudra.tools.registry import registry
    return await registry.execute(data.get("tool"), data.get("arguments",{}), user_id)

@app.get("/api/web/search")
async def web_search(q: str):
    results = await web.search(q)
    return {"query": q, "results": results}

@app.post("/api/web/crawl")
async def crawl(data: Dict[str, Any]):
    return await web.crawl(data.get("url",""))

@app.get("/api/integrations")
async def integrations_status():
    return integrations.status()

@app.post("/api/files/upload")
async def upload(file: UploadFile = File(...)):
    content = await file.read()
    path = file_manager.upload(file.filename, content)
    # Auto index
    info = file_manager.index_file(path)
    return {"path": path, "indexed": info}

@app.get("/api/files")
async def list_files():
    return file_manager.list_files()

@app.post("/api/vision/analyze")
async def analyze_vision(file: UploadFile = File(...), prompt: str = "Describe this image"):
    content = await file.read()
    p = Path(f"data/uploads/{file.filename}")
    p.parent.mkdir(exist_ok=True)
    p.write_bytes(content)
    result = await vision.understand_image(str(p), prompt)
    return result

@app.post("/api/voice/tts")
async def tts(data: Dict[str, Any]):
    path = await voice_system.text_to_speech(data.get("text","Hello Master"))
    return {"audio": path, "text": data.get("text")}

@app.post("/api/voice/stt")
async def stt(file: UploadFile = File(...)):
    audio = await file.read()
    text = await voice_system.speech_to_text(audio)
    return {"text": text}

@app.get("/api/metrics")
async def get_metrics():
    return metrics.summary()

@app.get("/api/security/audit")
async def audit():
    p = Path("logs/audit.log")
    if p.exists():
        lines = p.read_text().splitlines()[-50:]
        return {"audit": lines}
    return {"audit": []}

@app.post("/api/auth/token")
async def create_token(data: Dict[str, Any]):
    # Simple master token creation
    user_id = data.get("user_id", settings.master_user_id)
    token = security.create_token(user_id)
    return {"token": token, "user_id": user_id}

# === WebSocket ===
class ConnectionManager:
    def __init__(self):
        self.active: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        if ws in self.active: self.active.remove(ws)

    async def broadcast(self, message: Dict):
        for ws in self.active:
            try: await ws.send_json(message)
            except: pass

manager = ConnectionManager()

@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    await manager.connect(websocket)
    await websocket.send_json({"type": "connected", "message": f"RUDRA connected. Loyalty to Master. Hello {user_id}!"})
    try:
        while True:
            data = await websocket.receive_json()
            msg = data.get("message","")
            session_id = data.get("session_id")
            # Integrity check
            result = await rudra.chat(user_id, msg, session_id)
            await websocket.send_json({"type": "response", **result})
            # Broadcast to other connections if needed
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        await websocket.send_json({"type": "error", "error": str(e)})

# Internal API for agents
@app.get("/api/internal/status")
async def internal_status():
    return rudra.get_status()

@app.get("/api/guard/rules")
async def guard_rules():
    return guard.get_core_rules()
