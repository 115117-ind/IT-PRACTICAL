"""Phase 18 - Learning System"""
from typing import Dict, Any, List
from rudra.utils.logger import get_logger
from rudra.memory.manager import memory_manager

logger = get_logger("learning")

class LearningSystem:
    def __init__(self):
        self.feedback_buffer: List[Dict] = []

    def collect_feedback(self, user_id: str, message_id: str, rating: int, comment: str = ""):
        entry = {"user_id": user_id, "message_id": message_id, "rating": rating, "comment": comment}
        self.feedback_buffer.append(entry)
        logger.info(f"Feedback {rating}/5 from {user_id}: {comment[:100]}")
        # If positive, reinforce preference
        if rating >= 4 and comment:
            memory_manager.update_preference(user_id, f"liked_{message_id}", comment, confidence=0.8)

    def learn_preference(self, user_id: str, interaction: str, master_response: str):
        # Heuristic: extract likes/dislikes
        low = master_response.lower()
        if "i like" in low or "i love" in low or "prefer" in low:
            memory_manager.update_preference(user_id, "style_preference", master_response[:300])
        if "don't like" in low or "hate" in low or "not my taste" in low:
            memory_manager.update_preference(user_id, "dislike", master_response[:300])

    def update_knowledge(self, topic: str, content: str):
        from rudra.knowledge.base import knowledge_base
        knowledge_base.add("personal", topic, content)
        from rudra.retrieval.engine import retrieval
        retrieval.index(content, {"topic": topic})

    def summarize_conversation(self, user_id: str, messages: List[Dict]) -> str:
        summary = memory_manager.summarize_session(user_id, messages)
        # Extract preferences from last messages
        for m in messages[-5:]:
            if m.get("role") == "user":
                self.learn_preference(user_id, "", m.get("content",""))
        return summary

    def experience_storage(self, user_id: str, task: str, outcome: str, success: bool):
        memory_manager.add_episodic(user_id, f"Task: {task} -> {'Success' if success else 'Failed'}: {outcome[:200]}", {"task": task, "success": success})

learning = LearningSystem()
