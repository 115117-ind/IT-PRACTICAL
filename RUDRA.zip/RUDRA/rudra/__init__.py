"""R.U.D.R.A. - Real-time Universal Decision & Reasoning Agent"""
__version__ = "1.0.0"
__name__ = "R.UD.R.A."
