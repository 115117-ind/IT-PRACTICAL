"""Phase 10 - Tool System (UPGRADED)"""
from typing import Dict, List, Any, Callable, Optional
import inspect
from rudra.utils.logger import get_logger, audit_log
from rudra.core.immutable import guard
from rudra.config.settings import settings

logger = get_logger("tools")

class Tool:
    def __init__(self, name: str, description: str, func: Callable, permissions: List[str]=None, requires_master: bool=False):
        self.name = name
        self.description = description
        self.func = func
        self.permissions = permissions or []
        self.requires_master = requires_master
        self.signature = inspect.signature(func)

    def schema(self) -> Dict:
        props = {}
        for param, p in self.signature.parameters.items():
            props[param] = {"type": "string", "description": f"param {param}"}
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {"type": "object", "properties": props, "required": list(props.keys())}
            }
        }

class ToolRegistry:
    def __init__(self):
        self.tools: Dict[str, Tool] = {}
        self.execution_log: List[Dict] = []

    def register(self, tool: Tool):
        self.tools[tool.name] = tool
        logger.info(f"Tool registered: {tool.name}")

    def list_tools(self) -> List[str]:
        return list(self.tools.keys())

    def get_schemas(self) -> List[Dict]:
        return [t.schema() for t in self.tools.values()]

    async def execute(self, tool_name: str, arguments: Dict, requester_id: str) -> Any:
        if tool_name not in self.tools:
            return {"error": f"Tool {tool_name} not found"}
        tool = self.tools[tool_name]
        if tool.requires_master and requester_id != settings.master_user_id:
            audit_log(f"Tool {tool_name} denied for {requester_id} (master only)", user_id=requester_id, action="tool_denied")
            return {"error": f"Tool {tool_name} requires Master permission"}
        if tool_name in ["file_delete", "system_control"]:
            allowed, msg = guard.can_modify(arguments.get("path", ""), requester_id)
            if not allowed:
                return {"error": msg}
        try:
            logger.info(f"Executing tool {tool_name} for {requester_id} args={arguments}")
            if inspect.iscoroutinefunction(tool.func):
                result = await tool.func(**arguments)
            else:
                result = tool.func(**arguments)
            self.execution_log.append({"tool": tool_name, "args": arguments, "result": str(result)[:600], "user": requester_id})
            audit_log(f"Tool {tool_name} executed", user_id=requester_id, action=f"tool_{tool_name}")
            return {"success": True, "result": result}
        except Exception as e:
            logger.error(f"Tool {tool_name} failed: {e}")
            return {"error": str(e)}

# Global registry
registry = ToolRegistry()

# === UPGRADED BUILT-IN TOOLS ===
from pathlib import Path

async def web_search(query: str, max_results: str = "5"):
    """Real-time web search (Tavily→SerpAPI→DuckDuckGo) with crawling for citations"""
    from rudra.web.intelligence import web
    try:
        n = int(max_results) if str(max_results).isdigit() else 5
        n = max(1, min(n, 10))
        hits = await web.search_and_crawl(query, max_results=n, crawl_top_k=2)
        # Clean for JSON
        out = []
        for h in hits:
            out.append({
                "title": h.get("title",""),
                "url": h.get("url",""),
                "snippet": h.get("snippet","")[:400],
                "content": h.get("full_text", h.get("content",""))[:800],
                "source": h.get("source","web")
            })
        return {"query": query, "results": out, "count": len(out), "note": "Add TAVILY_API_KEY for advanced search; DuckDuckGo used as fallback"}
    except Exception as e:
        return {"error": str(e), "query": query}

async def crawl_url(url: str):
    """Fetch and extract readable text from a URL"""
    from rudra.web.intelligence import web
    return await web.crawl(url)

async def news_search(topic: str, max_results: str = "5"):
    """Search latest news for a topic"""
    from rudra.web.intelligence import web
    n = int(max_results) if str(max_results).isdigit() else 5
    hits = await web.news(topic, max_results=n)
    return {"topic": topic, "results": hits}

async def url_reader(url: str):
    """Read URL as clean text"""
    from rudra.web.intelligence import web
    text = await web.read_url(url)
    return {"url": url, "text": text[:8000]}

async def create_file(path: str, content: str):
    p = Path(path)
    if any(protected in str(p) for protected in ["rudra/core", "rudra/identity", "rudra/security"]):
        return {"error": "Cannot overwrite core files - protection active"}
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)
    return {"success": True, "path": str(p), "bytes": len(content)}

async def read_file(path: str):
    p = Path(path)
    if not p.exists():
        return {"error": "File not found"}
    return {"content": p.read_text()[:5000], "path": str(p)}

async def remember_preference(key: str, value: str, user_id: str = "owner_001"):
    from rudra.memory.manager import memory_manager
    memory_manager.update_preference(user_id, key, value)
    return {"saved": True, "key": key, "value": value}

# Register — now 7 tools
registry.register(Tool("web_search", "Search the web for live information (real-time, with crawling). Use for news, weather, facts, recent events, any query needing internet.", web_search))
registry.register(Tool("crawl_url", "Fetch a URL and extract readable article text", crawl_url))
registry.register(Tool("news_search", "Search latest news about a topic (real-time)", news_search))
registry.register(Tool("url_reader", "Read a URL as clean text (no HTML)", url_reader))
registry.register(Tool("create_file", "Create or write a file (protected core blocked)", create_file))
registry.register(Tool("read_file", "Read a file content", read_file))
registry.register(Tool("remember_preference", "Remember Master's preference/taste", remember_preference))
