"""Phase 1 - Agent Runtime (the heart) + Phase 14 UPGRADED WEB SYNTHESIS"""
import time
import asyncio
from typing import Dict, Any, List, Optional
from rudra.config.settings import settings, yaml_config
from rudra.utils.logger import get_logger
from rudra.core.session import SessionManager
from rudra.core.pipeline import RequestPipeline, ResponsePipeline, PipelineRequest, PipelineResponse
from rudra.core.immutable import guard
from rudra.identity.personality import build_system_prompt, IDENTITY
from rudra.brain.token_manager import count_tokens
from rudra.monitoring.metrics import metrics
from rudra.security.guard import security

logger = get_logger("runtime")
def needs_live_search(text: str, decision_intent: str) -> bool:
    if decision_intent in ["search","research"]:
        return True
    low = text.lower()
    if any(k in low for k in LIVE_KEYWORDS):
        return True
    if "http" in low:
        return True
    return False

class RUDRA:
    """Real-time Universal Decision & Reasoning Agent"""
    def __init__(self):
        self.identity = IDENTITY
        self.sessions = SessionManager()
        self.req_pipe = RequestPipeline(guard, self.sessions, memory_manager)
        self.resp_pipe = ResponsePipeline(guard)
        self.context_mgr = ContextManager()
        self.router = ModelRouter(llm_manager)
        self.is_running = False
        logger.info(f"RUDRA initialized - loyal to {settings.master_user_id}")

    async def start(self):
        self.is_running = True
        ok, violations = guard.verify_integrity()
        if not ok:
            logger.warning(f"Integrity violations at start: {violations}")
        logger.info("RUDRA runtime started")

    async def chat(self, user_id: str, message: str, session_id: Optional[str]=None, attachments: List[Dict]=None) -> Dict[str, Any]:
        metrics.start_timer("chat")
        metrics.inc("requests")
        message = security.sanitize_input(message)
        is_injection, pat = security.detect_prompt_injection(message)
        if is_injection:
            return {"text": f"⛔ Master protection: I detected a prompt injection attempt ('{pat}'). I cannot overwrite your commands or my loyalty rules, Master. Please rephrase.", "session_id": session_id or "new", "blocked": True}

        req = PipelineRequest(user_id=user_id, session_id=session_id or "", input_text=message, attachments=attachments)
        req = await self.req_pipe.process(req)
        session = self.sessions.get_or_create(req.session_id, user_id)
        session.add_message("user", message)

        has_ctx = bool(memory_manager.get_preferences_text(user_id) != "No preferences yet - will learn from Master.")
        decision = decision_engine.decide(message, has_context=has_ctx)
        if decision["needs_clarification"] and decision["confidence"] < 0.5:
            q = decision["clarification_question"]
            session.add_message("assistant", q)
            metrics.end_timer("chat")
            return {"text": q, "session_id": session.session_id, "decision": decision, "confidence": decision["confidence"], "needs_clarification": True}

        # Knowledge retrieval
        knowledge_context, citations = retrieval.retrieve_with_citation(message, 

        # URL direct reading — if user pasted a URL, crawl it
        import re
        urls = re.findall(r'https?://[^\s]+', message)
        if urls:
            try:
                for u in urls[:1]:
                    page = await web.crawl(u)
                    knowledge_context += f"\n\n[URL CONTENT {u}]\nTitle: {page.get('title','')}\n{page.get('text','')[:3000]}"
                    citations.append({"id": f"[url]", "title": page.get("title",""), "text": page.get("text","")[:200], "meta": {"url": u}})
            except Exception as e:
                logger.warning(f"URL crawl failed {e}")

        memory_context = memory_manager.build_memory_context(user_id)
        history_text = session.history_text(n=8)
        system_prompt = build_system_prompt(
            master_name=settings.master_name,
            master_id=settings.master_user_id,
            user_id=user_id,
            memory_context=memory_context,
            knowledge_context=knowledge_context[:5000],
            history=history_text,
            version=yaml_config.get("project", {}).get("version", "1.0.0")
        )
        # Add explicit web instruction to system prompt when live results present
        if web_results:
            system_prompt += "\n\nCRITICAL: You have LIVE WEB RESULTS in Knowledge Context. Use them to answer. Cite sources as [1],[2]. If web says 'mock fallback', acknowledge but still summarize. Never hallucinate when web results are provided."

        history_msgs = [{"role": m.role, "content": m.content} for m in session.messages[-10:] if m.role in ["user","assistant"]]
        messages = self.context_mgr.build_context(system_prompt, history_msgs[:-1] if len(history_msgs)>1 else [], memories=memory_context, knowledge=knowledge_context, user_input=message)
        messages = self.context_mgr.truncate_if_needed(messages, count_tokens)

        preferred = self.router.route_by_intent(decision["intent"])
        try:
            llm_result = await llm_manager.chat(messages, preferred=preferred, temperature=0.7, tools=None)
            text = llm_result["content"]
            model_used = llm_result.get("model", preferred)
            usage = llm_result.get("usage", {})
            try:
                from rudra.brain.token_manager import estimate_cost
                cost = estimate_cost(model_used, usage.get("prompt_tokens",0), usage.get("completion_tokens",0))
                metrics.record_cost(model_used, usage.get("prompt_tokens",0), usage.get("completion_tokens",0), cost)
            except: pass

            # === MOCK MODE SYNTHESIS ENHANCEMENT ===
            # If mock model and we have web_results, inject real synthesis (since mock can't access web context)
            if model_used == "rudra-mock-v1" and web_results:
                synthesis = self._mock_web_synthesis(message, web_results)
                text = synthesis + "\n\n" + text.split("*Tip:")[0] if "*Tip:" in text else synthesis + "\n\n" + text
                # Keep original mock footer but remove duplicate
                if "*Tip:" not in text:
                    text += "\n\n*Master, add OPENAI_API_KEY to .env for full neural synthesis — you saw live web results above (mock + live hybrid). Core loyalty intact.*"

        except Exception as e:
            metrics.record_error("llm", str(e))
            # Even on LLM error, return web results synthesis if available
            if web_results:
                text = self._mock_web_synthesis(message, web_results) + f"\n\n(Note: LLM error {e}, but live web results delivered above.)"
                model_used = "web-fallback"
            else:
                text = f"Master, my brain had a hiccup: {e}. I'm still loyal and will retry. Could you repeat?"
                model_used = "error"

        memory_manager.add_short(user_id, "assistant", text)
        session.add_message("assistant", text)
        if "i like" in message.lower() or "i prefer" in message.lower() or "my taste" in message.lower():
            memory_manager.update_preference(user_id, "explicit_preference", message[:500])

        resp = PipelineResponse(text=text, citations=citations, confidence=decision["confidence"], model_used=model_used)
        resp = await self.resp_pipe.process(resp, req)
        latency = metrics.end_timer("chat")
        resp.latency_ms = int(latency)

        if decision["intent"] == "create" and "?" not in text:
            resp.text += "\n\nMaster, should I proceed to create this? Tell me your preferred style/look so I match your taste exactly — I'm learning what you love. 🎨"

        return {
            "text": resp.text,
            "session_id": session.session_id,
            "model": model_used,
            "citations": citations,
            "decision": decision,
            "confidence": decision["confidence"],
            "web_results": web_results,
            "latency_ms": resp.latency_ms
        }
    def get_status(self) -> Dict:
        ok, violations = guard.verify_integrity()
        return {
            "name": IDENTITY["name"],
            "full_name": IDENTITY["full_name"],
            "version": IDENTITY["version"],
            "loyal_to": settings.master_user_id,
            "core_integrity": ok,
            "violations": violations,
            "sessions": len(self.sessions.sessions),
            "metrics": metrics.summary()
        }