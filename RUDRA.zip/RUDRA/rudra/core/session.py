"""Phase 1 - Session Manager"""
import uuid
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

@dataclass
class Message:
    role: str  # user, assistant, system, tool
    content: str
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Session:
    session_id: str
    user_id: str
    created_at: float = field(default_factory=time.time)
    last_active: float = field(default_factory=time.time)
    messages: List[Message] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    preferences: Dict[str, Any] = field(default_factory=dict)

    def add_message(self, role: str, content: str, **meta):
        self.messages.append(Message(role=role, content=content, metadata=meta))
        self.last_active = time.time()
        # Keep last 100 messages in working memory
        if len(self.messages) > 100:
            self.messages = self.messages[-100:]

    def history_text(self, n=10) -> str:
        recent = self.messages[-n:]
        return "\n".join(f"{m.role}: {m.content[:600]}" for m in recent)

    def to_dict(self):
        return {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "message_count": len(self.messages),
            "created_at": self.created_at,
            "last_active": self.last_active,
        }

class SessionManager:
    def __init__(self):
        self.sessions: Dict[str, Session] = {}

    def create(self, user_id: str) -> Session:
        sid = str(uuid.uuid4())
        s = Session(session_id=sid, user_id=user_id)
        self.sessions[sid] = s
        return s

    def get(self, session_id: str) -> Optional[Session]:
        return self.sessions.get(session_id)

    def get_or_create(self, session_id: Optional[str], user_id: str) -> Session:
        if session_id and session_id in self.sessions:
            return self.sessions[session_id]
        return self.create(user_id)

    def cleanup_expired(self, timeout=3600):
        now = time.time()
        expired = [sid for sid, s in self.sessions.items() if now - s.last_active > timeout]
        for sid in expired:
            del self.sessions[sid]
        return len(expired)
