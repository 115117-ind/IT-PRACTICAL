"""Phase 1 - Request / Response Pipeline"""
from dataclasses import dataclass
from typing import Any, Dict, List
@dataclass
class PipelineRequest:
    user_id: str
    session_id: str
    input_text: str
    attachments: List[Dict[str, Any]] = None
    metadata: Dict[str, Any] = None
@dataclass
class PipelineResponse:
    text: str
    tool_calls: List[Dict] = None
    citations: List[Dict] = None
    confidence: float = 1.0
    latency_ms: int = 0
    model_used: str = ""