"""Phase 15 - Computer Control (safe, permission-gated)"""
from typing import Dict, Any
from rudra.utils.logger import get_logger, audit_log
from rudra.config.settings import settings

logger = get_logger("control")

class AutomationEngine:
    def __init__(self):
        self.enabled = True

    def _check_master(self, user_id: str) -> bool:
        if user_id != settings.master_user_id:
            audit_log(f"Control denied for {user_id}", user_id=user_id, action="control_denied")
            return False
        return True

    async def keyboard_type(self, text: str, user_id: str) -> Dict:
        if not self._check_master(user_id):
            return {"error": "Computer control requires Master permission"}
        try:
            import pyautogui
            pyautogui.typewrite(text)
            audit_log(f"Keyboard type: {text[:100]}", user_id=user_id, action="keyboard")
            return {"success": True, "typed": text[:100]}
        except Exception as e:
            return {"error": str(e), "note": "Install pyautogui and run on desktop with display"}

    async def mouse_click(self, x: int, y: int, user_id: str) -> Dict:
        if not self._check_master(user_id):
            return {"error": "Master only"}
        try:
            import pyautogui
            pyautogui.click(x, y)
            return {"success": True, "x": x, "y": y}
        except Exception as e:
            return {"error": str(e)}

    async def screenshot(self, user_id: str) -> Dict:
        if not self._check_master(user_id):
            return {"error": "Master only"}
        try:
            import pyautogui
            from pathlib import Path
            p = Path("data/screenshots")
            p.mkdir(exist_ok=True)
            path = p / "latest.png"
            pyautogui.screenshot(str(path))
            return {"success": True, "path": str(path)}
        except Exception as e:
            return {"error": str(e), "note": "Screenshot requires display"}

    async def clipboard_set(self, text: str, user_id: str) -> Dict:
        try:
            import pyperclip
            pyperclip.copy(text)
            return {"success": True}
        except: 
            return {"note": "Clipboard copy stub", "text": text[:200]}

    async def launch_app(self, app: str, user_id: str) -> Dict:
        if not self._check_master(user_id):
            return {"error": "Master only"}
        import subprocess, platform
        try:
            if platform.system() == "Windows":
                subprocess.Popen(app, shell=True)
            else:
                subprocess.Popen([app], shell=False)
            audit_log(f"Launched app {app}", user_id=user_id, action="launch")
            return {"success": True, "app": app}
        except Exception as e:
            return {"error": str(e)}

automation = AutomationEngine()
