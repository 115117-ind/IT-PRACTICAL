"""Phase 13 - File System"""
from pathlib import Path
import mimetypes
import shutil
from typing import List, Dict, Any
from rudra.utils.logger import get_logger
try:
    from pypdf import PdfReader
    HAS_PDF = True
except: HAS_PDF=False

logger = get_logger("fs")

class FileManager:
    def __init__(self, root: str = "data/uploads"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def upload(self, filename: str, content: bytes) -> str:
        dest = self.root / filename
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(content)
        logger.info(f"Uploaded {filename} ({len(content)} bytes)")
        return str(dest)

    def list_files(self) -> List[Dict]:
        files = []
        for p in self.root.rglob("*"):
            if p.is_file():
                files.append({"name": p.name, "path": str(p), "size": p.stat().st_size, "type": mimetypes.guess_type(str(p))[0]})
        return files

    def read(self, path: str) -> str:
        p = Path(path)
        if not p.exists():
            return "File not found"
        if p.suffix.lower() == ".pdf" and HAS_PDF:
            try:
                reader = PdfReader(str(p))
                text = "\n".join(page.extract_text() or "" for page in reader.pages)
                return text[:10000]
            except Exception as e:
                return f"PDF parse error: {e}"
        try:
            return p.read_text()[:10000]
        except:
            return f"Binary file {p.suffix}, size {p.stat().st_size}"

    def index_file(self, path: str) -> Dict:
        content = self.read(path)
        # Send to retrieval
        from rudra.retrieval.engine import retrieval
        retrieval.index(content, {"file": path})
        return {"indexed": True, "path": path, "chars": len(content)}

    def download(self, path: str) -> bytes:
        p = Path(path)
        return p.read_bytes() if p.exists() else b""

file_manager = FileManager()
