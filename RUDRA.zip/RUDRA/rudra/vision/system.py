"""Phase 17 - Vision System"""
from typing import Dict, List, Any
from pathlib import Path
from rudra.utils.logger import get_logger

logger = get_logger("vision")

class VisionSystem:
    def __init__(self):
        pass

    async def understand_image(self, image_path: str, prompt: str = "Describe this image") -> Dict:
        # Try OpenAI vision if key available
        try:
            import os, base64, httpx
            key = os.getenv("OPENAI_API_KEY")
            if key:
                b64 = base64.b64encode(Path(image_path).read_bytes()).decode()
                async with httpx.AsyncClient(timeout=30) as client:
                    resp = await client.post("https://api.openai.com/v1/chat/completions",
                        headers={"Authorization": f"Bearer {key}"},
                        json={
                            "model": "gpt-4o-mini",
                            "messages": [{"role": "user", "content": [
                                {"type": "text", "text": prompt},
                                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}
                            ]}]
                        })
                    data = resp.json()
                    return {"description": data["choices"][0]["message"]["content"], "model": "gpt-4o-mini"}
        except Exception as e:
            logger.warning(f"Vision API failed {e}")
        # Fallback: basic image info
        try:
            from PIL import Image
            im = Image.open(image_path)
            return {"description": f"Image {im.size[0]}x{im.size[1]} mode={im.mode} - [Add OPENAI_API_KEY for AI vision analysis]", "size": im.size}
        except Exception as e:
            return {"error": str(e)}

    async def ocr(self, image_path: str) -> str:
        try:
            import pytesseract
            from PIL import Image
            text = pytesseract.image_to_string(Image.open(image_path))
            return text[:5000]
        except Exception as e:
            return f"OCR unavailable ({e}) - install tesseract"

    async def object_detection(self, image_path: str) -> List[Dict]:
        # Stub - would use YOLO/detr in production
        return [{"label": "object", "confidence": 0.9, "note": "Add object detection model for real results"}]

    async def screen_understanding(self, screenshot_path: str) -> str:
        return await self.understand_image(screenshot_path, "You are RUDRA analyzing a computer screen. Describe UI elements, windows, and possible actions.")

vision = VisionSystem()
